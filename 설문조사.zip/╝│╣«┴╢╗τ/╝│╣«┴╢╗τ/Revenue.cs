﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 설문조사
{
    public class Revenue
    {
        public int 선택 { get; set; }
        public int 학생수 { get; set; }


    }
}
