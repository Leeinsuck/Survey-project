﻿namespace 설문조사
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.문항3번3 = new System.Windows.Forms.RadioButton();
            this.문항3번2 = new System.Windows.Forms.RadioButton();
            this.문항3번1 = new System.Windows.Forms.RadioButton();
            this.문항2번3 = new System.Windows.Forms.RadioButton();
            this.문항2번2 = new System.Windows.Forms.RadioButton();
            this.문항2번1 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.비대면 = new System.Windows.Forms.RadioButton();
            this.대면 = new System.Windows.Forms.RadioButton();
            this.오른쪽 = new System.Windows.Forms.Button();
            this.삼페이지 = new System.Windows.Forms.Button();
            this.이페이지 = new System.Windows.Forms.Button();
            this.첫페이지 = new System.Windows.Forms.Button();
            this.왼쪽 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.문항3번3);
            this.panel1.Controls.Add(this.문항3번2);
            this.panel1.Controls.Add(this.문항3번1);
            this.panel1.Controls.Add(this.문항2번3);
            this.panel1.Controls.Add(this.문항2번2);
            this.panel1.Controls.Add(this.문항2번1);
            this.panel1.Location = new System.Drawing.Point(40, 500);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(950, 300);
            this.panel1.TabIndex = 0;
            // 
            // 문항3번3
            // 
            this.문항3번3.AutoSize = true;
            this.문항3번3.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.문항3번3.Location = new System.Drawing.Point(800, 165);
            this.문항3번3.Name = "문항3번3";
            this.문항3번3.Size = new System.Drawing.Size(109, 29);
            this.문항3번3.TabIndex = 5;
            this.문항3번3.TabStop = true;
            this.문항3번3.Text = "기타사유";
            this.문항3번3.UseVisualStyleBackColor = true;
            // 
            // 문항3번2
            // 
            this.문항3번2.AutoSize = true;
            this.문항3번2.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.문항3번2.Location = new System.Drawing.Point(400, 165);
            this.문항3번2.Name = "문항3번2";
            this.문항3번2.Size = new System.Drawing.Size(313, 29);
            this.문항3번2.TabIndex = 4;
            this.문항3번2.TabStop = true;
            this.문항3번2.Text = "비대면이 공부하기 더 좋기 때문에";
            this.문항3번2.UseVisualStyleBackColor = true;
            // 
            // 문항3번1
            // 
            this.문항3번1.AutoSize = true;
            this.문항3번1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.문항3번1.Location = new System.Drawing.Point(0, 165);
            this.문항3번1.Name = "문항3번1";
            this.문항3번1.Size = new System.Drawing.Size(217, 29);
            this.문항3번1.TabIndex = 3;
            this.문항3번1.TabStop = true;
            this.문항3번1.Text = "학교 가기 싫기 때문에";
            this.문항3번1.UseVisualStyleBackColor = true;
            // 
            // 문항2번3
            // 
            this.문항2번3.AutoSize = true;
            this.문항2번3.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.문항2번3.Location = new System.Drawing.Point(800, 9);
            this.문항2번3.Name = "문항2번3";
            this.문항2번3.Size = new System.Drawing.Size(109, 29);
            this.문항2번3.TabIndex = 2;
            this.문항2번3.TabStop = true;
            this.문항2번3.Text = "기타사유";
            this.문항2번3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.문항2번3.UseVisualStyleBackColor = true;
            // 
            // 문항2번2
            // 
            this.문항2번2.AutoSize = true;
            this.문항2번2.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.문항2번2.Location = new System.Drawing.Point(400, 9);
            this.문항2번2.Name = "문항2번2";
            this.문항2번2.Size = new System.Drawing.Size(295, 29);
            this.문항2번2.TabIndex = 1;
            this.문항2번2.TabStop = true;
            this.문항2번2.Text = "대면이 공부하기 더 좋기 때문에";
            this.문항2번2.UseVisualStyleBackColor = true;
            // 
            // 문항2번1
            // 
            this.문항2번1.AutoSize = true;
            this.문항2번1.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.문항2번1.Location = new System.Drawing.Point(0, 9);
            this.문항2번1.Name = "문항2번1";
            this.문항2번1.Size = new System.Drawing.Size(307, 29);
            this.문항2번1.TabIndex = 0;
            this.문항2번1.TabStop = true;
            this.문항2번1.Text = "학교에서 해야한다고 하기 때문에";
            this.문항2번1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 13F);
            this.label1.Location = new System.Drawing.Point(30, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(661, 36);
            this.label1.TabIndex = 1;
            this.label1.Text = "문항 1 - 강의에서 대면과 비대면 어떤것을 선호합니까?";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 13F);
            this.label2.Location = new System.Drawing.Point(30, 400);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1188, 36);
            this.label2.TabIndex = 2;
            this.label2.Text = "문항 2 - 대면을 선택한 이유를 선택해주세요.(단, 이 문항은 대면을 선택 했을 때 체크 해주세요.)";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("맑은 고딕", 13F);
            this.label3.Location = new System.Drawing.Point(30, 600);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(1188, 36);
            this.label3.TabIndex = 0;
            this.label3.Text = "문항 3 - 비대면을 선택한 이유를 선택해주세요.(단, 이 문항은 비대면을 선택 했을 때 체크 해주세요.)";
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 20F);
            this.label4.Location = new System.Drawing.Point(310, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(700, 48);
            this.label4.TabIndex = 6;
            this.label4.Text = "대학교 강의 대면 비대면 선호도 조사하기";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.비대면);
            this.panel2.Controls.Add(this.대면);
            this.panel2.Location = new System.Drawing.Point(40, 300);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1159, 38);
            this.panel2.TabIndex = 7;
            // 
            // 비대면
            // 
            this.비대면.AutoSize = true;
            this.비대면.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.비대면.Location = new System.Drawing.Point(400, 4);
            this.비대면.Name = "비대면";
            this.비대면.Size = new System.Drawing.Size(91, 29);
            this.비대면.TabIndex = 1;
            this.비대면.TabStop = true;
            this.비대면.Text = "비대면";
            this.비대면.UseVisualStyleBackColor = true;
            // 
            // 대면
            // 
            this.대면.AutoSize = true;
            this.대면.Font = new System.Drawing.Font("맑은 고딕", 9F);
            this.대면.Location = new System.Drawing.Point(0, 4);
            this.대면.Name = "대면";
            this.대면.Size = new System.Drawing.Size(73, 29);
            this.대면.TabIndex = 0;
            this.대면.TabStop = true;
            this.대면.Text = "대면";
            this.대면.UseVisualStyleBackColor = true;
            // 
            // 오른쪽
            // 
            this.오른쪽.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.오른쪽.Location = new System.Drawing.Point(775, 845);
            this.오른쪽.Name = "오른쪽";
            this.오른쪽.Size = new System.Drawing.Size(50, 50);
            this.오른쪽.TabIndex = 12;
            this.오른쪽.Text = ">";
            this.오른쪽.UseVisualStyleBackColor = true;
            this.오른쪽.Click += new System.EventHandler(this.오른쪽_Click);
            // 
            // 삼페이지
            // 
            this.삼페이지.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.삼페이지.Location = new System.Drawing.Point(705, 845);
            this.삼페이지.Name = "삼페이지";
            this.삼페이지.Size = new System.Drawing.Size(50, 50);
            this.삼페이지.TabIndex = 11;
            this.삼페이지.Text = "3";
            this.삼페이지.UseVisualStyleBackColor = true;
            this.삼페이지.Click += new System.EventHandler(this.삼페이지_Click);
            // 
            // 이페이지
            // 
            this.이페이지.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.이페이지.Location = new System.Drawing.Point(635, 845);
            this.이페이지.Name = "이페이지";
            this.이페이지.Size = new System.Drawing.Size(50, 50);
            this.이페이지.TabIndex = 10;
            this.이페이지.Text = "2";
            this.이페이지.UseVisualStyleBackColor = true;
            // 
            // 첫페이지
            // 
            this.첫페이지.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.첫페이지.Location = new System.Drawing.Point(565, 845);
            this.첫페이지.Name = "첫페이지";
            this.첫페이지.Size = new System.Drawing.Size(50, 50);
            this.첫페이지.TabIndex = 9;
            this.첫페이지.Text = "1";
            this.첫페이지.UseVisualStyleBackColor = true;
            this.첫페이지.Click += new System.EventHandler(this.첫페이지_Click);
            // 
            // 왼쪽
            // 
            this.왼쪽.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.왼쪽.Location = new System.Drawing.Point(495, 845);
            this.왼쪽.Name = "왼쪽";
            this.왼쪽.Size = new System.Drawing.Size(50, 50);
            this.왼쪽.TabIndex = 8;
            this.왼쪽.Text = "<";
            this.왼쪽.UseVisualStyleBackColor = true;
            this.왼쪽.Click += new System.EventHandler(this.왼쪽_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1298, 924);
            this.Controls.Add(this.오른쪽);
            this.Controls.Add(this.삼페이지);
            this.Controls.Add(this.이페이지);
            this.Controls.Add(this.첫페이지);
            this.Controls.Add(this.왼쪽);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "대면 비대면 선호도 설문조사";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton 문항3번3;
        private System.Windows.Forms.RadioButton 문항3번2;
        private System.Windows.Forms.RadioButton 문항3번1;
        private System.Windows.Forms.RadioButton 문항2번3;
        private System.Windows.Forms.RadioButton 문항2번2;
        private System.Windows.Forms.RadioButton 문항2번1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.RadioButton 비대면;
        private System.Windows.Forms.RadioButton 대면;
        private System.Windows.Forms.Button 오른쪽;
        private System.Windows.Forms.Button 삼페이지;
        private System.Windows.Forms.Button 이페이지;
        private System.Windows.Forms.Button 첫페이지;
        private System.Windows.Forms.Button 왼쪽;
    }
}