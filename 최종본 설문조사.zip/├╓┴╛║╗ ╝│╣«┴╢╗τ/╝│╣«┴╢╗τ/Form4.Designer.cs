﻿namespace 설문조사
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.오른쪽 = new System.Windows.Forms.Button();
            this.삼페이지 = new System.Windows.Forms.Button();
            this.이페이지 = new System.Windows.Forms.Button();
            this.첫페이지 = new System.Windows.Forms.Button();
            this.왼쪽 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.문항4번 = new System.Windows.Forms.TextBox();
            this.문항5번 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // 오른쪽
            // 
            this.오른쪽.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.오른쪽.Location = new System.Drawing.Point(775, 845);
            this.오른쪽.Name = "오른쪽";
            this.오른쪽.Size = new System.Drawing.Size(50, 50);
            this.오른쪽.TabIndex = 17;
            this.오른쪽.Text = ">";
            this.오른쪽.UseVisualStyleBackColor = true;
            this.오른쪽.Click += new System.EventHandler(this.오른쪽_Click);
            // 
            // 삼페이지
            // 
            this.삼페이지.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.삼페이지.Location = new System.Drawing.Point(705, 845);
            this.삼페이지.Name = "삼페이지";
            this.삼페이지.Size = new System.Drawing.Size(50, 50);
            this.삼페이지.TabIndex = 16;
            this.삼페이지.Text = "3";
            this.삼페이지.UseVisualStyleBackColor = true;
            // 
            // 이페이지
            // 
            this.이페이지.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.이페이지.Location = new System.Drawing.Point(635, 845);
            this.이페이지.Name = "이페이지";
            this.이페이지.Size = new System.Drawing.Size(50, 50);
            this.이페이지.TabIndex = 15;
            this.이페이지.Text = "2";
            this.이페이지.UseVisualStyleBackColor = true;
            this.이페이지.Click += new System.EventHandler(this.이페이지_Click);
            // 
            // 첫페이지
            // 
            this.첫페이지.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.첫페이지.Location = new System.Drawing.Point(565, 845);
            this.첫페이지.Name = "첫페이지";
            this.첫페이지.Size = new System.Drawing.Size(50, 50);
            this.첫페이지.TabIndex = 14;
            this.첫페이지.Text = "1";
            this.첫페이지.UseVisualStyleBackColor = true;
            this.첫페이지.Click += new System.EventHandler(this.첫페이지_Click);
            // 
            // 왼쪽
            // 
            this.왼쪽.Font = new System.Drawing.Font("맑은 고딕", 12F);
            this.왼쪽.Location = new System.Drawing.Point(495, 845);
            this.왼쪽.Name = "왼쪽";
            this.왼쪽.Size = new System.Drawing.Size(50, 50);
            this.왼쪽.TabIndex = 13;
            this.왼쪽.Text = "<";
            this.왼쪽.UseVisualStyleBackColor = true;
            this.왼쪽.Click += new System.EventHandler(this.왼쪽_Click);
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("맑은 고딕", 20F);
            this.label4.Location = new System.Drawing.Point(310, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(700, 48);
            this.label4.TabIndex = 18;
            this.label4.Text = "대학교 강의 대면 비대면 선호도 조사하기";
            // 
            // 문항4번
            // 
            this.문항4번.Location = new System.Drawing.Point(40, 250);
            this.문항4번.Multiline = true;
            this.문항4번.Name = "문항4번";
            this.문항4번.Size = new System.Drawing.Size(1103, 219);
            this.문항4번.TabIndex = 19;
            // 
            // 문항5번
            // 
            this.문항5번.Location = new System.Drawing.Point(40, 550);
            this.문항5번.Multiline = true;
            this.문항5번.Name = "문항5번";
            this.문항5번.Size = new System.Drawing.Size(1103, 219);
            this.문항5번.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("맑은 고딕", 14F);
            this.label1.Location = new System.Drawing.Point(30, 200);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1028, 38);
            this.label1.TabIndex = 21;
            this.label1.Text = "문항 4 - 기타사유(단, 문항 2에 기타사유를 선택한 경우에 여기다가 적어주세요.)";
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("맑은 고딕", 14F);
            this.label2.Location = new System.Drawing.Point(30, 500);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(1028, 38);
            this.label2.TabIndex = 22;
            this.label2.Text = "문항 5 - 기타사유(단, 문항 3에 기타사유를 선택한 경우에 여기다가 적어주세요.)";
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(1298, 924);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.문항5번);
            this.Controls.Add(this.문항4번);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.오른쪽);
            this.Controls.Add(this.삼페이지);
            this.Controls.Add(this.이페이지);
            this.Controls.Add(this.첫페이지);
            this.Controls.Add(this.왼쪽);
            this.Name = "Form4";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "대면 비대면 선호도 설문조사";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button 오른쪽;
        private System.Windows.Forms.Button 삼페이지;
        private System.Windows.Forms.Button 이페이지;
        private System.Windows.Forms.Button 첫페이지;
        private System.Windows.Forms.Button 왼쪽;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox 문항4번;
        private System.Windows.Forms.TextBox 문항5번;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}